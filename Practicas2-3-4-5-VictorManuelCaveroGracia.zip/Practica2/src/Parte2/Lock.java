package Parte2;

public interface Lock {
	
	public abstract void takeLock();
	
	public abstract void releaseLock();
	
}
