package Parte2;

public class Producto {
	
	public Producto() {}
	
	public Producto(Producto producto) {}

	@Override
	public String toString() {
		return "Producto X";
	}
	
}
