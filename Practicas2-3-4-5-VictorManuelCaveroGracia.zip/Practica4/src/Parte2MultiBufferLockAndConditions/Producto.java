package Parte2MultiBufferLockAndConditions;

public class Producto {
	
	public Producto() {}
	
	public Producto(Producto producto) {}

	@Override
	public String toString() {
		return "Producto X";
	}
	
}
