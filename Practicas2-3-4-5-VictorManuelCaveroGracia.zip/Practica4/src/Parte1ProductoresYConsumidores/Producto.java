package Parte1ProductoresYConsumidores;

public class Producto {
	
	public Producto() {}
	
	public Producto(Producto producto) {}

	@Override
	public String toString() {
		return "Producto X";
	}
	
}
