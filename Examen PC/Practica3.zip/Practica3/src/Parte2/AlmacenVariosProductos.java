package Parte2;

import java.util.concurrent.Semaphore;

public class AlmacenVariosProductos implements Almacen {
	
	//private volatile List<Producto> _productos;
	
	// Asumimos que los productos siempre estan disponibles por lo que nos centramos solo en la sincronizacion 
	
	private volatile Semaphore _sincro;
	private volatile Semaphore _p; // Semaforo productores
	private volatile Semaphore _c; // Semaforo consumidores
	
	private volatile int _productores; // Cuenta el numero de productores actuales
	private volatile int _consumidores; // Cuenta el numero de pconsumidores actuales
	
	private volatile int _productoresEsperando;
	private volatile int _consumidoresEsperando;
	
	public AlmacenVariosProductos()
	{

		_sincro = new Semaphore(1);
		_p = new Semaphore(0);
		_c = new Semaphore(0);
		
		_productores = 0;
		_consumidores = 0;
		_productoresEsperando = 0;
		_consumidoresEsperando = 0;
	}

	@Override
	public void almacenar(Producto producto) {		
		
		try {
			_sincro.acquire();
			if(_consumidores > 0 && _productores > 0)
			{
				_productoresEsperando++;
				_sincro.release();
				_p.acquire();
			}
			_productores++;	
			
			_sincro.release();
		
			Thread th = Thread.currentThread();
			System.out.println("Hilo " + th.getName() + " almacena producto en el almacen");
		
			_sincro.acquire();
			_productores--;
			
			if (_consumidores == 0 && _productores == 0 && _productoresEsperando > 0)
			{
				_productoresEsperando--;
				_p.release();
			}
			else if(_productores == 0 && _consumidoresEsperando > 0)
			{
				_consumidoresEsperando--;
				_c.release();
			}
			else _sincro.release();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public Producto extraer(int i) {	//posicion del producto a consumir	
		
		try {
			_sincro.acquire();
		
			if(_productores > 0) 
			{
				_consumidoresEsperando++;
				_sincro.release();
				_c.acquire();
			}
			
			_consumidores++;
			
			if(_consumidoresEsperando > 0)
			{
				_consumidoresEsperando--;
				_c.release();
			}
			else _sincro.release();
		
			Thread th = Thread.currentThread();
			System.out.println("Hilo " + th.getName() + " extrae el producto " + i + " del almacen");
		
			_sincro.acquire();
			_consumidores--;
			
			if(_productores == 0 && _consumidoresEsperando > 0)
			{
				_consumidoresEsperando--;
				_c.release();
			}
			else if (_consumidores == 0 && _productores == 0 && _productoresEsperando > 0)
			{
				_productoresEsperando--;
				_p.release();
			}
			else _sincro.release();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		return new Producto();
	}

}
