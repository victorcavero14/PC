package Parte2;

import java.util.concurrent.atomic.AtomicInteger;

public class LockTicketMax implements Lock{

	private final int MAX;
	
	private volatile AtomicInteger number;
	private volatile AtomicInteger next;
    private volatile AtomicInteger turn[];
    
    public LockTicketMax(int max) 
    {
    	MAX = max;
    	number = new AtomicInteger(1);
    	next = new AtomicInteger(1);
    	
    	turn = new AtomicInteger[max+1];
    	for(int i = 0; i < max; i++)
    	{
    		turn[i] = new AtomicInteger();
    	}
    }
    
    public void takeLock()
    {
    	int i = Integer.parseInt(Thread.currentThread().getName());	
    	
    	if(number.compareAndSet(MAX, MAX)) turn[i].set(MAX);
    	else turn[i].set(number.getAndIncrement());
    	    	
    	while(turn[i].get() != next.get());	
    }

    public void releaseLock()
    {
    	if(next.compareAndSet(MAX,MAX));
    	else next.incrementAndGet();
    	
    	// no hace falta mas ya que solo un proceso a la vez llega aqui (El que tiene el ticket)
    }
    
}
