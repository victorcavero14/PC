package Parte2MultiBufferSynchronized;
public class Producto {
	
	public Producto() {}
	
	public Producto(Producto producto) {}

	@Override
	public String toString() {
		return "Producto X";
	}
	
}
