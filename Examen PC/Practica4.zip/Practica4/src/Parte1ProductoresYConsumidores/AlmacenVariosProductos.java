package Parte1ProductoresYConsumidores;


public class AlmacenVariosProductos implements Almacen {
	
	//private volatile List<Producto> _productos;
	private MonitorAlmacen _monitorAlmacen;
	
	public AlmacenVariosProductos()
	{
		//_productos = new ArrayList<Producto>();
		_monitorAlmacen = new MonitorAlmacen();
	}

	@Override
	public synchronized void almacenar(Producto producto) {	
		
		_monitorAlmacen.request_produce();
		
		Thread th = Thread.currentThread();
		System.out.println("Hilo " + th.getName() + " almacena producto en el almacen");
		
		_monitorAlmacen.release_produce();
	}

	@Override
	public synchronized Producto extraer(int i) {		
		
		_monitorAlmacen.request_consume();

		Thread th = Thread.currentThread();
		System.out.println("Hilo " + th.getName() + " extrae el producto " + i + " del almacen");

		
		_monitorAlmacen.release_consume();
		
		return new Producto();
	}

}
