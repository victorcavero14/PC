package Parte1ProductoresYConsumidores;

public class MonitorAlmacen {
	
	private volatile int _consumidores;
	private volatile int _productores;
	
	public MonitorAlmacen() {
		_consumidores = 0;
		_productores = 0;
	}
	
	public synchronized void request_produce()
	{
		try
		{
			if(_productores > 0 || _consumidores > 0) wait();
			_productores++;
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}

	}
	
	public synchronized void release_produce()
	{
		_productores--;
		notifyAll();
	}
	
	public synchronized void request_consume()
	{
		try
		{
			if(_productores > 0) wait();
			_consumidores++;
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}
	
	public synchronized void release_consume()
	{
		_consumidores--;
	}

}
